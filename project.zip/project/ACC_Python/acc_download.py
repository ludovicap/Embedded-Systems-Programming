
# Importiamo la libreria per la comunicazione seriale
# tra il computer e la STM32.
import serial

# Importiamo la libreria per leggere e gestire
# i campioni memorizzati nel file CSV.
import csv

# Importiamo il modulo pyplot della libreria Matplotlib
# per generare e salvare i grafici dei campioni registrati.
import matplotlib.pyplot as plt

# Indichiamo la porta seriale della STM32 sul Mac.
PORTA = "/dev/cu.usbmodem14403"

# Impostiamo la velocità di comunicazione a 115200 bit/s.
BAUDRATE = 115200

# Apriamo la comunicazione seriale con la STM32.
stm32 = serial.Serial(
    port=PORTA,                 # Porta seriale utilizzata.
    baudrate=BAUDRATE,          # Velocità di trasmissione.
    bytesize=serial.EIGHTBITS,  # 8 bit di dati.
    parity=serial.PARITY_EVEN,  # Parità pari.
    stopbits=serial.STOPBITS_TWO,  # 2 bit di stop.
    timeout=2                   # Attesa massima di 2 secondi per una lettura.
)

# Comunichiamo che la porta è stata aperta correttamente.
print("Connessione seriale aperta correttamente.")


# Inviamo alla STM32 il comando S per richiedere
# il numero di campioni completi registrati nella Flash.
stm32.write(b"S")

# Attendiamo che tutti i byte del comando siano trasmessi.
stm32.flush()

# Leggiamo la risposta della STM32 fino al terminatore di riga.
risposta = stm32.readline()

# Convertiamo i byte ricevuti in una stringa di testo.
risposta = risposta.decode("ascii").strip()

# Verifichiamo se abbiamo ricevuto una risposta.
if risposta:

    # Convertiamo la risposta in un numero intero.
    numero_campioni_flash = int(risposta)

    # Mostriamo quanti campioni sono registrati nella Flash.
    print("Campioni registrati:", numero_campioni_flash)

else:

    # Segnaliamo che non è arrivata una risposta.
    print("Nessuna risposta ricevuta dalla STM32.")

    # Chiudiamo la comunicazione seriale.
    stm32.close()

    # Interrompiamo il programma senza cancellare la Flash.
    raise SystemExit

# Inviamo alla STM32 il comando D per richiedere
# tutti i campioni registrati nel settore 7 della Flash.
stm32.write(b"D")

# Attendiamo che il comando sia stato trasmesso.
stm32.flush()

# Creiamo una lista per memorizzare le righe CSV ricevute.
campioni = []

# Indica se la STM32 ha iniziato a trasmettere i dati.
ricezione_iniziata = False

# Indica se la STM32 ha terminato la trasmissione.
ricezione_completata = False

# Leggiamo le righe trasmesse dalla STM32.
while True:

    # Attendiamo una riga dalla porta seriale.
    risposta = stm32.readline().decode("ascii").strip()

    # Se non riceviamo nulla entro il timeout,
    # interrompiamo la ricezione.
    if not risposta:
        print("Timeout durante la ricezione.")
        break

    # Riconosciamo l'inizio della trasmissione.
    if risposta == "BEGIN_ACC_DATA":
        ricezione_iniziata = True
        print("Inizio ricezione campioni.")
        continue

    # Riconosciamo la fine della trasmissione.
    if risposta == "END_ACC_DATA":
        ricezione_completata = True
        print("Fine ricezione campioni.")
        break

    # Memorizziamo le righe ricevute dopo BEGIN_ACC_DATA.
    if ricezione_iniziata:
        campioni.append(risposta)

# Calcoliamo il numero di campioni ricevuti,
# escludendo la prima riga che contiene l'intestazione CSV.
numero_campioni_ricevuti = max(0, len(campioni) - 1)

# Confrontiamo il numero dei campioni ricevuti
# con quello comunicato dalla STM32 tramite il comando S.
if numero_campioni_ricevuti == numero_campioni_flash:

    print("Numero di campioni corretto.")

else:

    print("ATTENZIONE: numero di campioni non corrispondente.")

    print("Campioni registrati:", numero_campioni_flash)
    print("Campioni ricevuti:", numero_campioni_ricevuti)

# Indica se tutti i campioni ricevuti sono validi.
campioni_validi = True

# Memorizza il tempo del campione precedente.
tempo_precedente = None

# Controlliamo le righe dei campioni, escludendo
# la prima riga che contiene l'intestazione CSV.
for riga in campioni[1:]:

    # Separiamo i sei valori utilizzando la virgola.
    valori = riga.split(",")

    # Verifichiamo che il campione contenga sei valori.
    if len(valori) != 6:
        print("ERRORE: campione con numero di valori errato.")
        campioni_validi = False
        break

    try:

        # Convertiamo i valori nei rispettivi tipi.
        tempo = int(valori[0])
        distanza = float(valori[1])
        errore = float(valori[2])
        uk = float(valori[3])
        pwm = int(valori[4])
        stato = int(valori[5])

    except ValueError:

        # Uno dei valori ricevuti non è convertibile.
        print("ERRORE: campione contenente valori non validi.")
        campioni_validi = False
        break

    # Verifichiamo la continuità temporale.
    if tempo_precedente is not None:

        if tempo - tempo_precedente != 65:

            print("ERRORE: sequenza temporale non corretta.")
            campioni_validi = False
            break

    # Memorizziamo il tempo per il controllo successivo.
    tempo_precedente = tempo

# Verifichiamo che la trasmissione sia terminata.
if ricezione_completata:
    # Verifichiamo che la trasmissione sia iniziata e terminata,
    # che il numero dei campioni coincida con quello nella Flash
    # e che tutti i campioni ricevuti siano validi.
    trasferimento_valido = (
        ricezione_iniziata
        and ricezione_completata
        and numero_campioni_ricevuti == numero_campioni_flash
        and campioni_validi
        and numero_campioni_flash > 0
        and len(campioni) > 0
        and campioni[0] == "time_ms,distance,error,uk,pwm,state"
    )

    # Se tutte le verifiche sono state superate,
    # possiamo salvare il file CSV.
    if trasferimento_valido:

        # Apriamo il file CSV in modalità scrittura.
        with open("campioni_acc.csv", "w", encoding="ascii") as file:

            # Scriviamo tutte le righe ricevute.
            for riga in campioni:
                file.write(riga + "\n")

        print("Trasferimento verificato correttamente.")
        print("Campioni salvati:", numero_campioni_ricevuti)
        print("File campioni_acc.csv salvato correttamente.")

        # Creiamo le liste che conterranno i valori
        # necessari per rappresentare i grafici.
        tempi = []
        distanze = []
        errori = []
        uscite_pid = []
        pwm = []
        stati = []

        # Apriamo il file CSV appena salvato
        # per leggere i campioni registrati.
        with open("campioni_acc.csv", "r", encoding="ascii", newline="") as file:

            # Creiamo un lettore CSV che permette
            # di accedere ai valori attraverso i nomi delle colonne.
            lettore = csv.DictReader(file)

            # Scorriamo tutte le righe del file CSV.
            for riga in lettore:

                # Convertiamo il tempo da millisecondi a secondi.
                tempi.append(int(riga["time_ms"]) / 1000.0)

                # Memorizziamo la distanza misurata in centimetri.
                distanze.append(float(riga["distance"]))

                # Memorizziamo l'errore rispetto alla distanza di riferimento.
                errori.append(float(riga["error"]))

                # Memorizziamo l'uscita del controllore PID.
                uscite_pid.append(float(riga["uk"]))

                # Memorizziamo il valore PWM applicato ai motori.
                pwm.append(int(riga["pwm"]))

                # Memorizziamo lo stato della FSM.
                stati.append(int(riga["state"]))

        # Creiamo una nuova figura per il grafico della distanza.
        plt.figure()

        # Rappresentiamo la distanza misurata in funzione del tempo.
        plt.plot(tempi, distanze, label="Distanza misurata")

        # Aggiungiamo una linea orizzontale tratteggiata
        # che rappresenta la distanza desiderata di 30 cm.
        plt.axhline(y=30.0, linestyle="--", label="Distanza desiderata")

        # Impostiamo le etichette degli assi e il titolo.
        plt.xlabel("Tempo [s]")
        plt.ylabel("Distanza [cm]")
        plt.title("Distanza misurata dal sensore")

        # Visualizziamo la griglia e la legenda.
        plt.grid(True)
        plt.legend()

        # Salviamo il grafico come immagine PNG.
        plt.savefig("grafico_distanza.png", dpi=300)

        # Chiudiamo la figura per liberare la memoria.
        plt.close()

        # Creiamo una nuova figura per il grafico dell'errore.
        plt.figure()

        # Rappresentiamo l'errore di distanza in funzione del tempo.
        plt.plot(tempi, errori)

        # Aggiungiamo una linea di riferimento
        # corrispondente a un errore nullo.
        plt.axhline(y=0.0, linestyle="--")

        # Impostiamo le etichette degli assi e il titolo.
        plt.xlabel("Tempo [s]")
        plt.ylabel("Errore [cm]")
        plt.title("Errore di distanza")

        # Visualizziamo la griglia.
        plt.grid(True)

        # Salviamo il grafico dell'errore.
        plt.savefig("grafico_errore.png", dpi=300)

        # Chiudiamo la figura.
        plt.close()

        # Creiamo una nuova figura per l'uscita del PID.
        plt.figure()

        # Rappresentiamo il comando di controllo
        # calcolato dal PID in funzione del tempo.
        plt.plot(tempi, uscite_pid)

        # Impostiamo le etichette degli assi e il titolo.
        plt.xlabel("Tempo [s]")
        plt.ylabel("Uscita PID")
        plt.title("Comando di controllo PID")

        # Visualizziamo la griglia.
        plt.grid(True)

        # Salviamo il grafico dell'uscita PID.
        plt.savefig("grafico_pid.png", dpi=300)

        # Chiudiamo la figura.
        plt.close()

        # Creiamo una nuova figura per il PWM.
        plt.figure()

        # Rappresentiamo il PWM con un grafico a gradini,
        # perché il comando viene aggiornato a ogni campionamento.
        plt.step(tempi, pwm, where="post")

        # Impostiamo le etichette degli assi e il titolo.
        plt.xlabel("Tempo [s]")
        plt.ylabel("PWM")
        plt.title("PWM applicato ai motori")

        # Visualizziamo la griglia.
        plt.grid(True)

        # Salviamo il grafico del PWM.
        plt.savefig("grafico_pwm.png", dpi=300)

        # Chiudiamo la figura.
        plt.close()

        # Creiamo una nuova figura per gli stati della FSM.
        plt.figure()

        # Rappresentiamo lo stato della macchina a stati
        # utilizzando un grafico a gradini.
        plt.step(tempi, stati, where="post")

        # Impostiamo le etichette degli assi.
        plt.xlabel("Tempo [s]")
        plt.ylabel("Stato FSM")

        # Associamo ai valori numerici della FSM
        # i nomi degli stati definiti nel firmware.
        plt.yticks([0, 1, 2], ["STOP", "FORWARD", "BACKWARD"])

        # Impostiamo il titolo e visualizziamo la griglia.
        plt.title("Evoluzione degli stati della FSM")
        plt.grid(True)

        # Salviamo il grafico della FSM.
        plt.savefig("grafico_fsm.png", dpi=300)

        # Chiudiamo la figura.
        plt.close()

        # Comunichiamo che tutti i grafici sono stati generati.
        print("Tutti e cinque i grafici sono stati salvati correttamente.")

        # Chiediamo all'utente se vuole cancellare
        # i campioni registrati nel settore 7 della Flash.
        conferma = input(
            "Vuoi cancellare il settore 7 della Flash? (SI/NO): "
        )

        # Cancelliamo la Flash soltanto dopo conferma.
        if conferma.strip().upper() == "SI":

            # Inviamo il comando E alla STM32.
            stm32.write(b"E")
            stm32.flush()

            # Attendiamo la risposta della STM32.
            risposta_cancellazione = (
                stm32.readline().decode("ascii").strip()
            )

            # Verifichiamo l'esito della cancellazione.
            if risposta_cancellazione == "FLASH_ERASE_OK":
                print("Settore 7 cancellato correttamente.")

            else:
                print("ATTENZIONE: cancellazione non confermata.")
                print("Risposta STM32:", risposta_cancellazione)

        else:
            print("Cancellazione annullata.")

    else:

        # Se almeno una verifica fallisce,
        # non salviamo il CSV e non cancelliamo la Flash.
        print("ERRORE: trasferimento non verificato.")
        print("Campioni nella Flash:", numero_campioni_flash)
        print("Campioni ricevuti:", numero_campioni_ricevuti)
        print("I dati nella Flash non verranno cancellati.")
        print("È possibile ripetere il trasferimento.")

# Chiudiamo la comunicazione seriale.
stm32.close()

print("Connessione seriale chiusa.")
