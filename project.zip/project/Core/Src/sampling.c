/*
 * sampling.c
 *
 *  Created on: Oct 22, 2026
 *      Author: Ludovica, Andrea, Serena
 */


#include "sampling.h"
#include "main.h"


/** Flag che segnala il completamento del periodo di campionamento di 65 ms **/
volatile uint8_t time_elapsed = 0;

/** Numero di periodi di campionamento trascorsi **/
volatile uint32_t sample_count = 0;


/** Configurazione di TIM6 per la generazione del tempo di campionamento dell'ACC **/
void TIM6_basic_setup(void)
{
	/** Abilitiamo il clock della periferica TIM6 collegata al bus APB1 **/
	RCC->APB1ENR |= (1 << RCC_APB1ENR_TIM6EN_Pos);

	/** Abilitiamo gli eventi di aggiornamento **/
	TIM6->CR1 &= ~ (1 << TIM_CR1_UDIS_Pos);

	/** Selezioniamo l'overflow come sorgente della richiesta di interrupt **/
	TIM6->CR1 |= (1 << TIM_CR1_URS_Pos);

	/** Impostiamo il prescaler per ottenere un conteggio ogni 10 us **/
	TIM6->PSC = 840 - 1;

	/** Impostiamo ARR per ottenere un periodo di campionamento di 65 ms - TIM6 conterà da 0 a 6499 **/
	TIM6->ARR = 6500 - 1;

	/** Generiamo un evento di aggiornamento per caricare il prescaler **/
	TIM6->EGR |= (1 << TIM_EGR_UG_Pos);

	/** Abilitiamo la richiesta di interrupt per l'evento di aggiornamento **/
	TIM6->DIER |= (1 << TIM_DIER_UIE_Pos);

	/** Abilitiamo nel NVIC la linea di interrupt TIM6_DAC_IRQn associata a TIM6 **/
	NVIC_EnableIRQ(TIM6_DAC_IRQn);
	/** Impostiamo la priorità dell'interrupt di TIM6 al livello 1 **/
	NVIC_SetPriority(TIM6_DAC_IRQn,1);

	/** Abilitiamo il contatore di TIM6 (CEN = 1) **/
	TIM6->CR1 |= (1 << TIM_CR1_CEN_Pos);
}


/** Routine di gestione dell'interrupt di TIM6 **/
void TIM6_DAC_IRQHandler(void)
{
	/** Verifichiamo che il flag UIF segnali un evento di aggiornamento di TIM6 **/
	if((TIM6->SR >> TIM_SR_UIF_Pos) & 0x01)
	{
		/** Incrementiamo il numero di periodi trascorsi **/
		sample_count ++;

		/** Impostiamo il flag per segnalare che sono trascorsi 65 ms **/
		time_elapsed = 1;

		/** Azzeriamo il flag UIF per cancellare la segnalazione dell'evento gestito **/
		TIM6->SR &= ~(1 << TIM_SR_UIF_Pos);
	}
}
