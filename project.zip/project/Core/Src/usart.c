/*
 * usart.c
 *
 *  Created on: Oct 26, 2026
 *      Author: Ludovica, Andrea, Serena
 */


#include "usart.h"
#include "main.h"
#include "flash.h"
#include <stdio.h>

/** Configurazione di USART2 **/
void USART2_init(void)
{
	/** Abilitiamo il clock della porta GPIOA **/
	RCC->AHB1ENR |= (1 << RCC_AHB1ENR_GPIOAEN_Pos);


	// PA2 USART2 TX
	/** Configurazione del pin PA2 in AF **/
	GPIOA->MODER &= ~(3 << GPIO_MODER_MODER2_Pos);
	GPIOA->MODER |= (2 << GPIO_MODER_MODER2_Pos);

	/** Selezioniamo la AF7=0111 su PA2 **/
	GPIOA->AFR[0] &= ~(0xF << GPIO_AFRL_AFSEL2_Pos);
	GPIOA->AFR[0] |= (7 << GPIO_AFRL_AFSEL2_Pos);

	/** Configurazione della tipologia di pilotaggio dell'uscita (PA2 come uscita push-pull) **/
	GPIOA->OTYPER &= ~(1 << GPIO_OTYPER_OT2_Pos);



	// PA3 USART2 RX
	/** Configurazione del pin PA3 in AF **/
	GPIOA->MODER &= ~(3 << GPIO_MODER_MODER3_Pos);
	GPIOA->MODER |= (2 << GPIO_MODER_MODER3_Pos);

	/** Selezioniamo la AF7=0111 su PA3 **/
	GPIOA->AFR[0] &= ~(0xF << GPIO_AFRL_AFSEL3_Pos);
	GPIOA->AFR[0] |= (7 << GPIO_AFRL_AFSEL3_Pos);

	/** Configurazione della resistenza pull-up sul pin PA3 (USART2_RX) **/
	GPIOA->PUPDR &= ~(3 << GPIO_PUPDR_PUPD3_Pos);
	GPIOA->PUPDR |= (1 << GPIO_PUPDR_PUPD3_Pos);


	/** CONFIGURAZIONE USART2 **/
	/** Abilitiamo il clock della periferica USART2 **/
	RCC->APB1ENR |= (1 << RCC_APB1ENR_USART2EN_Pos);

	/** Lunghezza della parola trasmessa/ricevuta dalla USART (quanti bit contiene) **/
	USART2->CR1 |= (1 << USART_CR1_M_Pos);

	/** Abilitazione del controllo di parità **/
	USART2->CR1 |= (1 << USART_CR1_PCE_Pos);

	/** Impostiamo il bit di parità pari **/
	USART2->CR1 &= ~(1 << USART_CR1_PS_Pos);

	/** Configurazione di 2 bit di stop **/
	USART2->CR2 |= (2 << USART_CR2_STOP_Pos);

	/** Configurazione della mantissa del divisore USART2 per 115200 baud **/
	USART2->BRR |= (0x16 << USART_BRR_DIV_Mantissa_Pos);		//USARTDIV = 22,7865 ---> DIV_Mantissa = 22/16 = 1 con resto 6 = 0x16 (esadecimale)

	/** Configurazione della parte frazionaria del divisore USART2 per 115200 baud **/
	USART2->BRR |= (0xD << USART_BRR_DIV_Fraction_Pos);									//DIV_Fraction = 0,7865*16 = 12,58 = 13 = 0xD

	/** Abilitazione del trasmettitore USART2 (TX su PA2) **/
	USART2->CR1 |= (1 << USART_CR1_TE_Pos);

	/** Abilitazione del trasmettitore USART2 (RX su PA3) **/
	USART2->CR1 |= (1 << USART_CR1_RE_Pos);

	/** Abilitazione della periferica USART2 tramite il bit UE del registro CR1 **/
	USART2->CR1 |= (1 << USART_CR1_UE_Pos);
}


/** Trasmissione di un carattere tramite USART2 **/
void USART2_sendChar(char c)
{
    /** Attendiamo che il registro di trasmissione sia disponibile **/
    while (!(USART2->SR & (1 << USART_SR_TXE_Pos)));

    /** Scriviamo il carattere nel registro dati **/
    USART2->DR = c;
}


/** Trasmissione di una stringa tramite USART2 **/
void USART2_sendString(const char *str)
{
    while (*str != '\0')
    {
    	USART2_sendChar(*str);
    	str++;
    }
}

/** Ricezione di un carattere tramite USART2 **/
char USART2_receiveChar(void)
{
    /** Attendiamo la ricezione di un carattere **/
    while (!(USART2->SR & (1 << USART_SR_RXNE_Pos)));

    /** Leggiamo il carattere ricevuto **/
    return (char)(USART2->DR & 0xFF);		/** 0xFF = 11111111 (8 bit nel registro DR da leggere) **/
}


/** Legge un campione dalla Flash e lo trasmette
    al computer tramite USART2 in formato CSV. **/
void USART2_sendSample(uint32_t index)
{
    /** Struttura che conterrà i valori del campione letto. **/
    FLASH_Sample_t sample;

    /** Buffer di caratteri utilizzato per costruire la riga CSV. **/
    char buffer[128];

    /** Leggiamo il campione richiesto dalla Flash. **/
    if (FLASH_ReadSample(index, &sample) == 1U)
    {
        /** Convertiamo i valori del campione in una riga CSV.
            I valori vengono separati da virgole e la riga
            termina con ritorno a capo. **/
        int length = snprintf(buffer,
                              sizeof(buffer),
                              "%lu,%.3f,%.3f,%.3f,%lu,%lu\r\n",
                              (unsigned long)sample.time_ms,
                              (double)sample.distance,
                              (double)sample.error,
                              (double)sample.uk,
                              (unsigned long)sample.pwm,
                              (unsigned long)sample.state);

        /** Trasmettiamo la riga soltanto se è stata
            formattata correttamente e senza troncamenti. **/
        if (length > 0 && (size_t)length < sizeof(buffer))
        {
            USART2_sendString(buffer);
        }
    }
}


/** Trasmette tutti i campioni completi registrati
    nel settore 7 della Flash tramite USART2. **/
void USART2_sendAllSamples(void)
{
    /** Leggiamo una sola volta il numero dei campioni completi. **/
    uint32_t count = FLASH_CountSamples();

    /** Comunichiamo al computer l'inizio della trasmissione. **/
    USART2_sendString("BEGIN_ACC_DATA\r\n");

    /** Trasmettiamo l'intestazione delle colonne CSV. **/
    USART2_sendString("time_ms,distance,error,uk,pwm,state\r\n");

    /** Scorriamo tutti i campioni registrati nella Flash. **/
    for (uint32_t i = 0U; i < count; i++)
    {
        /** Leggiamo e trasmettiamo il campione corrente. **/
        USART2_sendSample(i);
    }

    /** Comunichiamo al computer la fine della trasmissione. **/
    USART2_sendString("END_ACC_DATA\r\n");
}


/** Trasmette un numero intero senza segno tramite USART2. **/
void USART2_sendNumber(uint32_t number)
{
    /** Buffer utilizzato per convertire il numero in testo. **/
    char buffer[16];

    /** Convertiamo il numero in caratteri decimali
        e aggiungiamo il terminatore di riga. **/
    snprintf(buffer, sizeof(buffer), "%lu\r\n", (unsigned long)number);

    /** Trasmettiamo il numero al computer. **/
    USART2_sendString(buffer);
}
