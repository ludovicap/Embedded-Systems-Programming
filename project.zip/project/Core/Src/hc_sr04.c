/*
 * hc_sr04.c
 *
 *  Created on: Oct 12, 2026
 *      Author: Ludovica, Andrea, Serena
 */


#include "hc_sr04.h"


/** Funzione di configurazione di base del TIM5 **/
static void TIM5_basic_setup()
{
	/** Abilitiamo il clock di TIM5 **/
	RCC -> APB1ENR |= (1U << 3);

	/** Impostiamo a 0 il bit UDIS (evento di aggiornamento abilitato) **/
	TIM5->CR1 &= ~(1U << 1);

	/** Impostiamo a 1 il bit URS che selezione l'overflow come sorgente di richiesta di interrupt **/
	TIM5->CR1 |= (1U << 2);

	/** Impostiamo il PSC per ottenere un conteggio ogni 1 us **/
	TIM5->PSC = 84 - 1;

	/** Generiamo un evento di aggiornamento per caricare il prescaler **/
	TIM5->EGR |= (1 << TIM_EGR_UG_Pos);

	/** Abilitiamo il bit UIE affinchè l'evento di aggiornamento generi una richiesta di interrupt **/
	TIM5->DIER |= (1U << 0);

	/* Configuriamo NVIC */
	NVIC_EnableIRQ(TIM5_IRQn);
	NVIC_SetPriority(TIM5_IRQn, 0);
}



/** Funzione di inizializzazione del sensore HC_SR04 **/
void hc_sr04_init()
{
	/** Abilitiamo clock della porta GPIOA utilizzata per Trigger ed Echo **/
	RCC->AHB1ENR |= (1U << 0);

	/** Configuriamo il pin Trigger su PA0 come uscita **/
	GPIOA->MODER &= ~(0x03 << 0);	/** Azzeriamo per sicurezza i bit **/
	GPIOA->MODER |= (0x01 << 0);	/** Impostiamo i bit a 01 **/

	/** Configuriamo PA0 come uscita Push-Pull **/
	GPIOA->OTYPER &= ~(0x01 << 0);

	/** Configuriamo il pin Echo su PA1 come ingresso **/
	GPIOA->MODER &= ~ (0x03 << 2);

	/** Colleghiamo PA alla linea EXTI1 **/
	SYSCFG->EXTICR[0] &= ~ (0xFU << 4);

	/** Configuriamo Interrupt esterno **/

		/** Configurazione Maschera Interrupt per PA1 **/
	EXTI->IMR |= (1U << 1);

		/** Riconoscimento fronte di discesa **/
	EXTI->FTSR |= (1U << 1);

		/** Riconoscimento fronte di salita **/
	EXTI->RTSR |= (1U << 1);


	/** Configuriamo NVIC **/
	NVIC_EnableIRQ(EXTI1_IRQn);
	NVIC_SetPriority(EXTI1_IRQn, 0);

	TIM5_basic_setup();
}


/** Flag che indica se è terminato il tempo di ritardo programmato **/
static volatile uint8_t time_elapsed = 0;

/** Funzione di gestione dell'interrupt di TIM5 **/
void TIM5_IRQHandler()
{
	/* Con bit UIF=0 nessun evento di aggiornamento
	 * Con bit UIF = 1 segnala evento di aggiornamento
	 */
	if((TIM5->SR >> TIM_SR_UIF_Pos) & 0x01)
	{
		/** NVIC mantiene la richiesta in attesa di essere gestita se la CPU non può farlo subito **/
		NVIC_ClearPendingIRQ(TIM5_IRQn);

		/** Segnala che il tempo del ritardo programmato è trascorso **/
		time_elapsed = 1;

		/** Disabilita il CEN (Counter ENable) quindi non è più abilitato a contare **/
		TIM5->CR1 &= ~ (1 << TIM_CR1_CEN_Pos);


		/** Azzero il bit UIF perchè non c'è più l'evento di aggiornamento **/
		TIM5->SR &= ~(1 << TIM_SR_UIF_Pos);
	}
}

/** Funzione per generare ritardi in microsecondi **/
static void delay_micro_s(uint16_t delay)
{
	/** Impostiamo la durata del conteggio prima di generare un evento di aggionramento **/
	TIM5->ARR = delay - 1;

	/** Inizializza il contatore **/
	TIM5->CNT = 0;

	/** Abilita il contatore a contare **/
	TIM5->CR1 |= (1 << TIM_CR1_CEN_Pos);

	/** Rimane nel while fin tanto che time_elapsed è zero, diventa 1 quando il tempo di ritardo programmato è trascorso **/
	while(!time_elapsed)
	{
	};

	/** Azzera il flag inerente al tempo di ritardo programmato **/
	time_elapsed = 0;
}


/** Variabile che indica che è ha finito di contare **/
static volatile uint8_t measure_collected = 0;

/** Inizializzazione del variabile che contiene il valore della misura **/
static volatile uint32_t measure = 0;

/** Funzione di gestione dell'interrupt di EXTI1 **/
void EXTI1_IRQHandler() {

	NVIC_ClearPendingIRQ(EXTI1_IRQn);

	if((GPIOA->IDR >> 1) & 0x01) {
		/** Limite del conteggio per Echo di 65 millisecondi **/
		TIM5->ARR = 65000;
		TIM5->CNT = 0;
		TIM5->CR1 |= (1 << TIM_CR1_CEN_Pos);
		measure_collected = 0;
	} else {
		TIM5->CR1 &= ~(1 << TIM_CR1_CEN_Pos);
		measure = TIM5->CNT;
		measure_collected = 1;
	}
	/** Scrivi 1 per cancellare - Impostiamo il bit PR1=1 per cancellare il flag della linea EXTI1 **/
	EXTI->PR |= (0x01 << EXTI_PR_PR1_Pos);
}


/** Funzione per impostare il pin Trigger PA0 a livello basso **/
void clear_trigger()
{
	GPIOA->ODR &= ~(1U << 0);
}


/** Funzione per impostare il pin Trigger PA0 a livello alto **/
void set_trigger()
{
	GPIOA->ODR |= (1U << 0);
}


/** Funzione che genera l'impulso Trigger, attende la misura di Echo e calcola la distanza **/
float meas_dist()
{
	clear_trigger();
	delay_micro_s(3);

	set_trigger();
	delay_micro_s(10);
	clear_trigger();

	while(!measure_collected)
	{
	};

	return measure * 0.0343f * 0.5f;		/** misura in cm **/
}
