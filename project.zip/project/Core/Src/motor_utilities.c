/*
 * motor_utilities.c
 *
 *  Created on: Oct 15, 2026
 *      Author: Ludovica, Andrea, Serena
 */


#include "motor_utilities.h"
#include "main.h"

/** Definizione delle maschere di bit associate ai segnali di direzione dei motori **/
#define MOTOR_M1A (1U << 2)  // QC - bit 2
#define MOTOR_M1B (1U << 3)  // QD - bit 3

#define MOTOR_M2A (1U << 1)  // QB - bit 1
#define MOTOR_M2B (1U << 4)  // QE - bit 4

#define MOTOR_M3A (1U << 0)  // QA - bit 0
#define MOTOR_M3B (1U << 6)  // QG - bit 6

#define MOTOR_M4A (1U << 5)  // QF - bit 5
#define MOTOR_M4B (1U << 7)  // QH - bit 7

/** Abilitazione e disabilitazione delle uscite del 74HC595N **/

/** Funzione per abilitare le uscite del 74HC595N **/
void ShiftRegister_enableOutputs(void)
{
	GPIOA->ODR &= ~(1 << GPIO_ODR_OD8_Pos);
}

/** Funzione per disabilitare le uscite del 74HC595N **/
static void ShiftRegister_disableOutputs(void)
{
	GPIOA->ODR |= (1 << GPIO_ODR_OD8_Pos);
}

/** Inizializzazione dei pin dello shift register **/
void ShiftRegister_init(void)
{
	/** Abilitiamo clock della porta GPIOA **/
	RCC->AHB1ENR |= (1 << RCC_AHB1ENR_GPIOAEN_Pos);

	/** Abilitiamo clock della porta GPIOB **/
	RCC->AHB1ENR |= (1 << RCC_AHB1ENR_GPIOBEN_Pos);

	/** Impostiamo pin PA9(DIR_SER) a livello logico basso **/
	GPIOA->ODR &= ~(1 << GPIO_ODR_OD9_Pos);

	/** Impostiamo pin PB5(DIR_CLK) a livello logico basso **/
	GPIOB->ODR &= ~(1 << GPIO_ODR_OD5_Pos);

	/** Impostiamo pin PA6(DIR_LATCH) a livello logico basso **/
	GPIOA->ODR &= ~(1 << GPIO_ODR_OD6_Pos);

	/** Impostiamo pin PA8(DIR_EN) a livello logico alto **/
	ShiftRegister_disableOutputs();		/** GPIOA->ODR |= (1 << GPIO_ODR_OD8_Pos); **/

	/** Configurazione pin PA9(DIR_SER) come GPIOA_Output **/
	GPIOA->MODER &= ~(3 << GPIO_MODER_MODER9_Pos);
	GPIOA->MODER |= (1 << GPIO_MODER_MODER9_Pos);

	/** Configurazione pin PB5(DIR_CLK) come GPIOB_Output **/
	GPIOB->MODER &= ~(3 << GPIO_MODER_MODER5_Pos);
	GPIOB->MODER |= (1 << GPIO_MODER_MODER5_Pos);

	/** Configurazione pin PA6(DIR_LATCH) come GPIOA_Output **/
	GPIOA->MODER &= ~(3 << GPIO_MODER_MODER6_Pos);
	GPIOA->MODER |= (1 << GPIO_MODER_MODER6_Pos);

	/** Configurazione pin PA8(DIR_EN) come GPIOA_Output **/
	GPIOA->MODER &= ~(3 << GPIO_MODER_MODER8_Pos);
	GPIOA->MODER |= (1 << GPIO_MODER_MODER8_Pos);
}


/** Funzione per inviare 8 bit  al 74HC595N **/
static void ShiftRegister_shiftOut(uint8_t data)
{
	/** Leggiamo un singolo bit dalla variabile data dal bit più significativo al meno significativo **/
	for (int i = 7; i >= 0; i--)
	{
		//** Leggiamo un bit per volta **//
		uint8_t bit = (data >> i) & 1;

		/** Ad ogni iterazione, assegniamo a PA9(DIR_SER), il valore del bit da trasmettere **/
		if (bit == 1)
		{
			GPIOA->ODR |= (1 << GPIO_ODR_OD9_Pos);
		}
		else
		{
			GPIOA->ODR &= ~(1 << GPIO_ODR_OD9_Pos);
		}

		/** Generiamo un impulso di clock su PB5(DIR_CLK) **/
		GPIOB->ODR |= (1 << GPIO_ODR_OD5_Pos);
		/** Riportiamo PB5 a zero per preparare il prossimo impulso **/
		GPIOB->ODR &= ~(1 << GPIO_ODR_OD5_Pos);
	}

	/** Trasferiamo gli 8 bit al registro di uscita del 74HC595N **/
	GPIOA->ODR |= (1 << GPIO_ODR_OD6_Pos);
	/** Riportiamo DIR_LATCH a livello logico basso **/
	GPIOA->ODR &= ~(1 << GPIO_ODR_OD6_Pos);
}


/** Impostazione della direzione dei motori **/
void Motor_setDirection(uint8_t direction)
{
	ShiftRegister_shiftOut(direction);
}


/** Comandi di movimento **/

/** Funzione per impostare il primo verso di rotazione dei motori **/
void Motor_forward(void)
{
	/*
	 * M1(posteriore destra)	ingresso B = 1, ingresso A = 0
	 * M2(anteriore destra)		ingresso A = 1, ingresso B = 0
	 * M3(anteriore sinistra)	ingresso A = 1, ingresso B = 0
	 * M4(posteriore sinistra	ingresso B = 1, ingresso A = 0.
	 *
	 * 1H 0G 0F 0E 1D 0C 1B 1A	 M1A M1B=CD=01   M2A M2B=BE=10   M3A M3B=AG=10   M4A M4B=FH=01
	 */
    Motor_setDirection(MOTOR_M1B | MOTOR_M2A | MOTOR_M3A | MOTOR_M4B); 	  // 0H 0G 1F 0E 0D 1C 1B 1A	 M1A M1B=CD=10   M2A M2B=BE=10   M3A M3B=AG=10   M4A M4B=FH=10
}

/** Funzione per impostare il verso opposto di rotazione dei motori **/
void Motor_backward(void)
{
	/*
		 * M1(posteriore destra)	ingresso A = 1, ingresso B = 0,
		 * M2(anteriore destra)		ingresso B = 1, ingresso A = 0
		 * M3(anteriore sinistra)	ingresso B = 1, ingresso A = 0
		 * M4(posteriore sinistra	ingresso A = 1, ingresso B = 0.
		 *
		 * 0H 1G 1F 1E 0D 1C 0B 0A	 M1A M1B=CD=10   M2A M2B=BE=01   M3A M3B=AG=01   M4A M4B=FH=10
		 */
	Motor_setDirection(MOTOR_M1A | MOTOR_M2B | MOTOR_M3B | MOTOR_M4A);    // 1H 1G 0F 1E 1D 0C 0B 0A	 M1A M1B=CD=01   M2A M2B=BE=01   M3A M3B=AG=01   M4A M4B=FH=01
}

/** Funzione per impostare l'arresto dei motori **/
void Motor_stop(void)
{
	Motor_setDirection(0);
}


/** Configurazione del PWM del motore M1 **/
void TIM3_PWM_setup(void)
{
	/** Abilitiamo il clock della porta GPIOA **/
	RCC->AHB1ENR |= (1 << RCC_AHB1ENR_GPIOAEN_Pos);

	/** Configurazione pin PA7 in modalità Alternate Function **/
	GPIOA->MODER &= ~(3 << GPIO_MODER_MODER7_Pos);
	GPIOA->MODER |= (2 << GPIO_MODER_MODER7_Pos);

	/** Configurazione della AF2 per PA7 (TIM3_CH2) **/
	GPIOA->AFR[0] &= ~(0xFU << 28);	/**  AFR[0] = AFRL **/
	GPIOA->AFR[0] |= (2 << 28);

	/** Configurazione della velocità di commutazione di PA7 in Very High Speed **/
	GPIOA->OSPEEDR &= ~ (3 << 14);
	GPIOA->OSPEEDR |= (3 << 14);

	/** Abilitazione del clock del timer TIM3 **/
	RCC->APB1ENR |= (1 << RCC_APB1ENR_TIM3EN_Pos);

	/** Abilitazione degli eventi di aggiornamento del timer TIM3 **/
	TIM3->CR1 &= ~(1 << TIM_CR1_UDIS_Pos);		/** Impostato a 0 è abilitato **/

	/** Configurazione delle sorgenti delle richieste di aggiornamento **/
	TIM3->CR1 |= (1 << TIM_CR1_URS_Pos);		/** Selezioniamo l'overflow come sorgente della richiesta di interrupt di aggiornamento **/

	/** Configurazione di TIM3 con conteggio crescente (DIR = 0) **/
	TIM3->CR1 &= ~(1 << TIM_CR1_DIR_Pos);

	/** Selezione della modalità Edge-aligned (CMS = 00), quindi TIM3 conta da 0 a ARR per generare il PWM **/
	TIM3->CR1 &= ~(3 << TIM_CR1_CMS_Pos);

	/** Abilitazione del preload di ARR: il nuovo periodo viene applicato al successivo evento di aggiornamento di TIM3 **/
	TIM3->CR1 |= (1 << TIM_CR1_ARPE_Pos);

	/** Configurazione del canale 2 di TIM3 come uscita (CC2S = 00) **/
	TIM3->CCMR1 &= ~(3 << TIM_CCMR1_CC2S_Pos);

	/** Abilitazione del preload di CCR2 (OC2PE = 1), il nuovo duty cycle viene applicato al successivo evento di aggiornamento del timer **/
	TIM3->CCMR1 |= (1 << TIM_CCMR1_OC2PE_Pos);

	/** Selezione della modalità PWM 1 (OC2M = 110) **/
	TIM3->CCMR1 &= ~(7 << TIM_CCMR1_OC2M_Pos);
	TIM3->CCMR1 |= (6 << TIM_CCMR1_OC2M_Pos);

	/** Abilitazione dell'uscita PWM del canale 2 di TIM3 (CC2E = 1) **/
	TIM3->CCER |= (1 << TIM_CCER_CC2E_Pos);

	/** Selezione della polarità attiva alta del PWM (CC2P = 0) **/
	TIM3->CCER &= ~(1 << TIM_CCER_CC2P_Pos);		/** Lo impostiamo attivo alto (polarità normale) perchè il driver L293D richiede un segnale di abilitazione attivo alto **/

	/** Configurazione del prescaler di TIM3 ottenendo un conteggio ogni microsecondo **/
	TIM3->PSC = 84 - 1;

	/** Configurazione del periodo del PWM: TIM3 conta da 0 a 999, completando un ciclo ogni 1 ms e ottenendo una frequenza di 1 kHz **/
	TIM3->ARR = 1000 - 1;

	/** Impostazione iniziale de duty cycle allo 0% **/
    TIM3->CCR2 = 0;

	/** Generazione di un evento di aggiornamento: caricamento dei valori iniziali di PSC, ARR e CCR2 **/
	TIM3->EGR |= (1 << TIM_EGR_UG_Pos);
}


/** Configurazione del PWM del motore M2 **/
void TIM2_PWM_setup(void)
{
	/** Abilitiamo il clock della porta GPIOB **/
	RCC->AHB1ENR |= (1 << RCC_AHB1ENR_GPIOBEN_Pos);

	/** Configurazione pin PB3 in modalità Alternate Function **/
	GPIOB->MODER &= ~(3 << GPIO_MODER_MODER3_Pos);
	GPIOB->MODER |= (2 << GPIO_MODER_MODER3_Pos);

	/** Configurazione della AF1 per PB3 (TIM2_CH2) **/
	GPIOB->AFR[0] &= ~(0xFU << 12);	/**  AFR[0] = AFRL **/
	GPIOB->AFR[0] |= (1 << 12);

	/** Configurazione della velocità di commutazione di PB3 in Very High Speed **/
	GPIOB->OSPEEDR &= ~ (3 << 6);
	GPIOB->OSPEEDR |= (3 << 6);

	/** Abilitazione del clock del timer TIM2 **/
	RCC->APB1ENR |= (1 << RCC_APB1ENR_TIM2EN_Pos);

	/** Abilitazione degli eventi di aggiornamento del timer TIM2 **/
	TIM2->CR1 &= ~(1 << TIM_CR1_UDIS_Pos);		/** Impostato a 0 è abilitato **/

	/** Configurazione delle sorgenti delle richieste di aggiornamento **/
	TIM2->CR1 |= (1 << TIM_CR1_URS_Pos);		/** Selezioniamo l'overflow come sorgente della richiesta di interrupt di aggiornamento **/

	/** Configurazione di TIM2 con conteggio crescente (DIR = 0) **/
	TIM2->CR1 &= ~(1 << TIM_CR1_DIR_Pos);

	/** Selezione della modalità Edge-aligned (CMS = 00), quindi TIM2 conta da 0 a ARR per generare il PWM **/
	TIM2->CR1 &= ~(3 << TIM_CR1_CMS_Pos);

	/** Abilitazione del preload di ARR: il nuovo periodo viene applicato al successivo evento di aggiornamento di TIM2 **/
	TIM2->CR1 |= (1 << TIM_CR1_ARPE_Pos);

	/** Configurazione del canale 2 di TIM2 come uscita (CC2S = 00) **/
	TIM2->CCMR1 &= ~(3 << TIM_CCMR1_CC2S_Pos);

	/** Abilitazione del preload di CCR2 (OC2PE = 1), il nuovo duty cycle viene applicato al successivo evento di aggiornamento del timer **/
	TIM2->CCMR1 |= (1 << TIM_CCMR1_OC2PE_Pos);

	/** Selezione della modalità PWM 1 (OC2M = 110) **/
	TIM2->CCMR1 &= ~(7 << TIM_CCMR1_OC2M_Pos);
	TIM2->CCMR1 |= (6 << TIM_CCMR1_OC2M_Pos);

	/** Abilitazione dell'uscita PWM del canale 2 di TIM2 (CC2E = 1) **/
	TIM2->CCER |= (1 << TIM_CCER_CC2E_Pos);

	/** Selezione della polarità attiva alta del PWM (CC2P = 0) **/
	TIM2->CCER &= ~(1 << TIM_CCER_CC2P_Pos);		/** Lo impostiamo attivo alto (polarità normale) perchè il driver L293D richiede un segnale di abilitazione attivo alto **/

	/** Configurazione del prescaler di TIM2 ottenendo un conteggio ogni microsecondo **/
	TIM2->PSC = 84 - 1;

	/** Configurazione del periodo del PWM: TIM2 conta da 0 a 999, completando un ciclo ogni 1 ms e ottenendo una frequenza di 1 kHz **/
	TIM2->ARR = 1000 - 1;

	/** Impostazione iniziale de duty cycle allo 0% **/
    TIM2->CCR2 = 0;

	/** Generazione di un evento di aggiornamento: caricamento dei valori iniziali di PSC, ARR e CCR2 **/
	TIM2->EGR |= (1 << TIM_EGR_UG_Pos);
}


/** Configurazione del PWM del motore M3 **/
void TIM2_CH3_PWM_setup(void)
{
	/** Abilitiamo il clock della porta GPIOB **/
	RCC->AHB1ENR |= (1 << RCC_AHB1ENR_GPIOBEN_Pos);

	/** Configurazione pin PB10 in modalità Alternate Function **/
	GPIOB->MODER &= ~(3 << GPIO_MODER_MODER10_Pos);
	GPIOB->MODER |= (2 << GPIO_MODER_MODER10_Pos);

	/** Configurazione della AF1 per PB10 (TIM2_CH3) **/
	GPIOB->AFR[1] &= ~(0xFU << 8);	/**  AFR[1] = AFRH **/
	GPIOB->AFR[1] |= (1 << 8);

	/** Configurazione della velocità di commutazione di PB10 in Very High Speed **/
	GPIOB->OSPEEDR &= ~ (3 << 20);
	GPIOB->OSPEEDR |= (3 << 20);

	/** Configurazione del canale 3 di TIM2 come uscita (CC3S = 00) **/
	TIM2->CCMR2 &= ~(3 << TIM_CCMR2_CC3S_Pos);

	/** Abilitazione del preload di CCR3 (OC3PE = 1), il nuovo duty cycle viene applicato al successivo evento di aggiornamento del timer **/
	TIM2->CCMR2 |= (1 << TIM_CCMR2_OC3PE_Pos);

	/** Selezione della modalità PWM 1 (OC3M = 110) **/
	TIM2->CCMR2 &= ~(7 << TIM_CCMR2_OC3M_Pos);
	TIM2->CCMR2 |= (6 << TIM_CCMR2_OC3M_Pos);

	/** Abilitazione dell'uscita PWM del canale 3 di TIM2 (CC3E = 1) **/
	TIM2->CCER |= (1 << TIM_CCER_CC3E_Pos);

	/** Selezione della polarità attiva alta del PWM (CC3P = 0) **/
	TIM2->CCER &= ~(1 << TIM_CCER_CC3P_Pos);		/** Lo impostiamo attivo alto (polarità normale) perchè il driver L293D richiede un segnale di abilitazione attivo alto **/

	/** Impostazione iniziale de duty cycle allo 0% **/
    TIM2->CCR3 = 0;
}


/** Configurazione del PWM del motore M4 **/
void TIM3_CH1_PWM_setup(void)
{
	/** Abilitiamo il clock della porta GPIOB **/
	RCC->AHB1ENR |= (1 << RCC_AHB1ENR_GPIOBEN_Pos);

	/** Configurazione pin PB4 in modalità Alternate Function **/
	GPIOB->MODER &= ~(3 << GPIO_MODER_MODER4_Pos);
	GPIOB->MODER |= (2 << GPIO_MODER_MODER4_Pos);

	/** Configurazione della AF2 per PB4 (TIM3_CH1) **/
	GPIOB->AFR[0] &= ~(0xFU << 16);	/**  AFR[0] = AFRL **/
	GPIOB->AFR[0] |= (2 << 16);

	/** Configurazione della velocità di commutazione di PB4 in Very High Speed **/
	GPIOB->OSPEEDR &= ~ (3 << 8);
	GPIOB->OSPEEDR |= (3 << 8);

	/** Configurazione del canale 1 di TIM3 come uscita (CC1S = 00) **/
	TIM3->CCMR1 &= ~(3 << TIM_CCMR1_CC1S_Pos);

	/** Abilitazione del preload di CCR1 (OC1PE = 1), il nuovo duty cycle viene applicato al successivo evento di aggiornamento del timer **/
	TIM3->CCMR1 |= (1 << TIM_CCMR1_OC1PE_Pos);

	/** Selezione della modalità PWM 1 (OC1M = 110) **/
	TIM3->CCMR1 &= ~(7 << TIM_CCMR1_OC1M_Pos);
	TIM3->CCMR1 |= (6 << TIM_CCMR1_OC1M_Pos);

	/** Abilitazione dell'uscita PWM del canale 1 di TIM3 (CC1E = 1) **/
	TIM3->CCER |= (1 << TIM_CCER_CC1E_Pos);

	/** Selezione della polarità attiva alta del PWM (CC1P = 0) **/
	TIM3->CCER &= ~(1 << TIM_CCER_CC1P_Pos);		/** Lo impostiamo attivo alto (polarità normale) perchè il driver L293D richiede un segnale di abilitazione attivo alto **/

	/** Impostazione iniziale de duty cycle allo 0% **/
    TIM3->CCR1 = 0;
}


/** Impostazione del PWM dei quattro motori **/
void Motor_setPWM(uint16_t pwm)
{
	TIM3->CCR2 = pwm; //M1
	TIM2->CCR2 = pwm; //M2
	TIM2->CCR3 = pwm; //M3
	TIM3->CCR1 = pwm; //M4
}

