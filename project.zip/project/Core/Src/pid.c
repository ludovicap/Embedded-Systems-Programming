/*
 * pid.c
 *
 *  Created on: Oct 22, 2026
 *      Author: Ludovica, Andrea, Serena
 */

#include "pid.h"
#include <stdlib.h>

/** Creazione e inizializzazione del controllore PID **/
Pid_s *pid_create(float tc, float kp, float ti, float td, float N, float u_min, float u_max, float tw)
{
	/** Allocazione dinamica della memoria necessaria a contenere la struttura Pid_s **/
	Pid_s *pid = malloc(sizeof(Pid_s));

	/** Verifica della corretta allocazione di memoria **/
	if(!pid)
		return NULL;

	/** Inizializzazione dei parametri del controllore PID **/
	pid->tc = tc;
	pid->kp = kp;
	pid->ti = ti;
	pid->td = td;
	pid->N = N;

	/** Inizializzazione dei parametri di saturazione e anti-windup **/
	pid->u_min = u_min;
	pid->u_max = u_max;
	pid->tw = tw;

	/** Inizializzazione delle variabili di stato del controllore PID **/

	/** Errore del campionamento precedente **/
	pid->e_km1 = 0.0f;

	/** Contributo integrale del campionamento precedente **/
	pid->u_i_km1 = 0.0f;

	/** Contributo derivativo del campionamento precedente **/
	pid->u_d_km1 = 0.0f;

	/** Restituisce il puntatore alla struttura PID **/
	return pid;
}


/** Calcolo del comando del controllore PID **/
float pid_calculate(Pid_s *pid, float measure, float reference)
{

	/* 1) Errore:
	       e[k] = y[k] – r[k] */

	/** Calcolo dell'errore tra distanza misurata e distanza desiderata **/
	float e_k = measure - reference;



	/* 2) Filtro derivativo:
	       a = T_d / (N·T_c)
	       u_d[k] = (a·u_d[k–1] + K_p·(T_d/T_c)·(e[k] – e[k–1])) / (a + 1) */

	/** Calcolo del coefficiente del filtro derivativo **/
	float a = pid->td / (pid->N * pid->tc);
	/** Calcolo del numeratore della componente derivativa **/
	float num = a * pid->u_d_km1 + pid->kp * (pid->td / pid->tc) * (e_k - pid->e_km1);
	/** Calcolo del denominatore della componente derivativa **/
	float den = a + 1.0f;

	/** Calcolo della componente derivativa filtrata **/
	float u_dk = num / den;



	/* 3) Calcolo provvisorio della componente integrale in forma incrementale :
	       u_i[k] = u_i[k–1] + K_p·(T_c/T_i)·e[k] */
	float u_ik = pid->u_i_km1 + pid->kp * (pid->tc / pid->ti) * e_k;




	/* 4) Calcolo del comando di controllo non saturato, sommando i contributi proporzionale, integrale e derivativo:
	       u_unsat[k] = K_p·e[k] + u_i[k] + u_d[k] */
	float u_unsat = pid->kp * e_k + u_ik + u_dk;



	/* 5) Saturazione del comando di controllo entro i limiti minimo e massimo:
	       u_sat[k] = clamp(u_unsat[k], u_min, u_max) */

	float u_sat = u_unsat;

    if (u_sat > pid->u_max)
    {
    	u_sat = pid->u_max;
    }
    else if (u_sat < pid->u_min)
    {
    	u_sat = pid->u_min;
    }



	/* 6) Anti-windup (back-calculation):
	       e_t[k] = u_sat[k] – u_unsat[k]
	       u_i[k] += (T_c/T_w)·e_t[k] */

    /** Calcolo della differenza tra comando saturato e non saturato **/
    float e_t = u_sat - u_unsat;
    /** Correzione della componente integrale mediante anti-windup **/
    u_ik += (pid->tc / pid->tw) * e_t;


	/** 7) **/

    /** Memorizzazione dell'errore attuale per il campionamento successivo **/
    pid->e_km1   = e_k;

    /** Memorizzazione della componente integrale corretta **/
    pid->u_i_km1 = u_ik;

    /** Memorizzazione della componente derivativa filtrata **/
    pid->u_d_km1 = u_dk;




	/* 8) Restituzione del comando di controllo entro i limiti consentiti:
	       u[k] = u_sat[k] */
    return u_sat;
}
