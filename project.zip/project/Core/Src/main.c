/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "hc_sr04.h"
#include "motor_utilities.h"
#include "sampling.h"
#include "pid.h"
#include "flash.h"
#include "usart.h"


/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/** Definizione degli stati della FSM **/
typedef enum
{
	ACC_STOP,		   //0
	ACC_FORWARD,       //1
	ACC_BACKWARD,      //2

} ACC_State_t;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/** Distanza di riferimento dell'ACC, espressa in centimetri **/
#define ACC_TARGET_CM 30.0f

/** Banda di tolleranza attorno alla distanza di riferimento **/
#define ACC_HOLD_BAND_CM 0.5f

/** Banda di ripartenza della macchinina **/
#define ACC_MOVE_BAND_CM 1.5f

/** PWM minimo necessario per avviare i motori **/
#define ACC_PWM_MIN 650U

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/


/* USER CODE BEGIN PV */

/** Variabile che memorizza lo stato corrente della FSM **/
static ACC_State_t acc_state = ACC_STOP;

/** Variabile contenente la misura del sensore **/
float measure_f;


/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  /* USER CODE BEGIN 2 */


  /** Inizializza e configura il sensore **/
  hc_sr04_init();

  /** Inizializzazione dello shift register **/
  ShiftRegister_init();

  /** Arresto dei motori **/
  Motor_stop();

  /** Abilitazione delle uscite dello shift register **/
  ShiftRegister_enableOutputs();

  /** Configurazione del PWM del motore M1 attraverso TIM3_CH2 **/
  TIM3_PWM_setup();

  /** Configurazione del PWM del motore M2 attraverso TIM2_CH2 **/
  TIM2_PWM_setup();

  /** Configurazione del PWM del motore M3 attraverso TIM2_CH3 **/
  TIM2_CH3_PWM_setup();

  /** Configurazione del PWM del motore M4 attraverso TIM3_CH1 **/
  TIM3_CH1_PWM_setup();

  /** Avvio del contatore TIM3 (CEN = 1) **/
  TIM3->CR1 |= (1 << TIM_CR1_CEN_Pos);

  /** Avvio del contatore TIM2 (CEN = 1) **/
  TIM2->CR1 |= (1 << TIM_CR1_CEN_Pos);

  /** Controlliamo il settore 7 e abilitiamo la registrazione
      soltanto se è completamente vuoto. **/
  FLASH_LogInit();


  /** Verifichiamo se la registrazione è abilitata. **/
  if (flash_recording_enabled == 1U)
  {
      /** Il settore 7 è vuoto: avviamo TIM6
          per generare un campionamento ogni 65 ms. **/
      TIM6_basic_setup();
  }

  else
  {
      /** Il settore 7 contiene già dei dati:
          impostiamo il PWM a zero. **/
      Motor_setPWM(0);

      /** Arrestiamo tutti i motori. **/
      Motor_stop();

      /** Inizializziamo USART2 per comunicare con il computer. **/
      USART2_init();

      /** Rimaniamo in attesa dei comandi inviati dal computer. **/
      while (1)
      {
          /** Attendiamo la ricezione di un carattere tramite USART2. **/
          char command = USART2_receiveChar();

          /** Verifichiamo se il computer ha richiesto
              lo scaricamento dei dati. **/
          if (command == 'D')
          {
              /** Trasmettiamo tutti i campioni registrati nella Flash. **/
              USART2_sendAllSamples();
          }

          /** Verifichiamo se il computer richiede
              il numero di campioni registrati. **/
          else if (command == 'S')
          {
              /** Leggiamo il numero dei campioni completi nella Flash. **/
              uint32_t count = FLASH_CountSamples();

              /** Trasmettiamo al computer il numero dei campioni. **/
              USART2_sendNumber(count);
          }


          /** Verifichiamo se il computer richiede
              la cancellazione del settore 7 della Flash. **/
          else if (command == 'E')
          {
              /** Richiamiamo la funzione che cancella il settore 7
                  e controlliamo se l'operazione è riuscita. **/
              if (FLASH_EraseSector7() == 1U)
              {
                  /** Comunichiamo al computer che il settore
                      è stato cancellato correttamente. **/
                  USART2_sendString("FLASH_ERASE_OK\r\n");
              }
              else
              {
                  /** Comunichiamo al computer che si è verificato
                      un errore durante la cancellazione. **/
                  USART2_sendString("FLASH_ERASE_ERROR\r\n");
              }
          }
      }
  }

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */


  /** Periodo di campionamento del PID: 65 ms **/
  float tc = 0.065f;

  /** Guadagno proporzionale **/
  float kp = 0.05f;			//0.06 aumentare per aumentare la reattività

  /** Tempo integrale **/
  float ti = 5.0f;			//0.9 diminuire se l'errore a regime non si azzera mai, aumentare se oscilla avanti/dietro o movimenti strani

  /** Tempo derivativo **/
  float td = 0.25f;		   //0.25 aumentare se frena troppo tardi e urta l'oggetto	0.1-0.2

  /** Coefficiente del filtro derivativo **/
  float N = 15.0f;			//20 aumentare se il sensore fa saltare uscita dei motori a causa del rumore acustico 10-20

  /** Costante di tempo dell'anti-windup **/
  float tw = ti;

  /** Limiti del comando di controllo **/
  float u_min = -1.0f;
  float u_max = 1.0f;

  /** Creazione e inizializzazione del controllore PID **/
  Pid_s *my_pid = pid_create(tc,
                             kp,
                             ti,
                             td,
                             N,
                             u_min,
                             u_max,
                             tw);


  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

	  /** Eseguiamo la FSM soltanto quando la registrazione
	      è abilitata ed è trascorso il periodo di campionamento di 65ms. **/
	  if ((flash_recording_enabled == 1U) && (time_elapsed))
	  {
		  /** Azzera il flag per attendere il successivo periodo **/
		  time_elapsed = 0;

		  /** Tempo nominale associato al campionamento **/
		  uint32_t time_ms = sample_count * 65U;

		  /** Restituisce la distanza misurata dal sensore  **/
		  measure_f = meas_dist();

		  /** Inizializzazione del comando PWM **/
		  uint16_t duty = 0;

		  /** Inizializzazione dell'uscita PID **/
		  float uk = 0.0f;

		  /** Calcolo dell'errore di distanza **/
		  float error = measure_f - ACC_TARGET_CM;

		  /** Gestione della FSM per ACC **/
		  switch (acc_state)
		  {
		  	  case ACC_STOP:
		  		  /** Impostazione del duty cycle allo 0% per tutti i motori **/
				  Motor_setPWM(0);

				  /** Impostazione dell'arresto dei motori **/
				  Motor_stop();

				  /** Verifica se la distanza è superiore alla soglia di ripartenza **/
				  if (measure_f > ACC_TARGET_CM + ACC_MOVE_BAND_CM)
				  {
					  acc_state = ACC_FORWARD;
				  }
				  /** Verifica se la distanza è inferiore alla soglia di ripartenza **/
				  else if (measure_f < ACC_TARGET_CM - ACC_MOVE_BAND_CM)
				  {
					  acc_state = ACC_BACKWARD;
				  }
				  break;


		  	  case ACC_FORWARD:

		  		  /** Passaggio diretto dall'avanzamento alla retromarcia **/
		  		  if (measure_f < ACC_TARGET_CM - ACC_MOVE_BAND_CM)
		  	      {
		  			  Motor_setPWM(0);
		  			  Motor_stop();

		  			  acc_state = ACC_BACKWARD;

		  			  /** Reinizializzazione della memoria del PID **/
		  			  my_pid->e_km1 = 0.0f;
		  			  my_pid->u_i_km1 = 0.0f;
		  			  my_pid->u_d_km1 = 0.0f;
		  	      }

		  	      /** Arresto quando la distanza rientra nella banda **/
		  	      else if (measure_f <= ACC_TARGET_CM + ACC_HOLD_BAND_CM)
		  	      {
		  	    	  acc_state = ACC_STOP;

		  	    	  Motor_setPWM(0);
		  	    	  Motor_stop();

		  	    	  /** Reinizializzazione della memoria del PID **/
		  	    	  my_pid->e_km1 = 0.0f;
		  	    	  my_pid->u_i_km1 = 0.0f;
		  	    	  my_pid->u_d_km1 = 0.0f;
		  	      }

		  	      /** Prosecuzione dell'avanzamento **/
		  	      else
		  	      {
		  	    	  /** Calcolo del PID **/
					  uk = pid_calculate(my_pid, measure_f, ACC_TARGET_CM);

					  /** Calcolo del valore assoluto **/
					  float uk_abs = (uk > 0.0f) ? uk : 0.0f;

					  /** Conversione dell'uscita PID in PWM **/
					  uint32_t pwm_max = TIM3->ARR;

					  if (uk_abs > 0.0f)
					  {
					      duty = (uint16_t)(ACC_PWM_MIN +
					             uk_abs * (pwm_max - ACC_PWM_MIN));
					  }
					  else
					  {
					      duty = 0;
					  }

					  Motor_forward();
					  Motor_setPWM(duty);
		  	      }

		  		  break;

		  	  case ACC_BACKWARD:

		  		  /** Passaggio diretto dalla retromarcia all'avanzamento **/
		  		  if (measure_f > ACC_TARGET_CM + ACC_MOVE_BAND_CM)
		  		  {
		  			  Motor_setPWM(0);
		  			  Motor_stop();

		  			  acc_state = ACC_FORWARD;

		  			  /** Reinizializzazione della memoria del PID **/
		  			  my_pid->e_km1 = 0.0f;
		  			  my_pid->u_i_km1 = 0.0f;
		  			  my_pid->u_d_km1 = 0.0f;
		  		  }

		  		  /** Arresto quando la distanza rientra nella banda **/
		  		  else if (measure_f >= ACC_TARGET_CM - ACC_HOLD_BAND_CM)
		  		  {
		  			  acc_state = ACC_STOP;

		  			  Motor_setPWM(0);
		  			  Motor_stop();

		  			  /** Reinizializzazione della memoria del PID **/
		  			  my_pid->e_km1 = 0.0f;
		  			  my_pid->u_i_km1 = 0.0f;
		  			  my_pid->u_d_km1 = 0.0f;
		  		  }

		  		  /** Prosecuzione della retromarcia **/
		  		  else
		  		  {
		  			  /** Calcolo del PID **/
		  			  uk = pid_calculate(my_pid, measure_f, ACC_TARGET_CM);

		  			  /** Calcolo del valore assoluto **/
		  			  float uk_abs = (uk < 0.0f) ? -uk : 0.0f;

		  			/** Conversione dell'uscita PID in PWM **/
		  			uint32_t pwm_max = TIM3->ARR;

		  			if (uk_abs > 0.0f)
		  			{
		  			    duty = (uint16_t)(ACC_PWM_MIN +
		  			           uk_abs * (pwm_max - ACC_PWM_MIN));
		  			}
		  			else
		  			{
		  			    duty = 0;
		  			}

		  			  Motor_backward();
		  			  Motor_setPWM(duty);
		  		  }

		  		  break;

		  	  default:
		  		  break;

		  }

		  /** Registrazione del campione ACC nella Flash **/
		  FLASH_LogSample(time_ms,
				  	  	  measure_f,
						  error,
						  uk,
						  duty,
						  (uint32_t)acc_state);
	  }
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}


/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LD2_GPIO_Port, LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
