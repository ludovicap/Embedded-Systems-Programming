
/*
 * flash.c
 *
 *  Created on: Oct 28, 2026
 *      Author: Ludovica, Andrea, Serena
 */

#include "flash.h"
#include <string.h>


/** Indirizzo iniziale del settore 7 della Flash. **/
#define FLASH_START_ADDRESS  0x08060000UL

/** Primo indirizzo successivo al settore 7. **/
#define FLASH_END_ADDRESS    0x08080000UL

/** Valore che identifica un campione completo. **/
#define FLASH_SAMPLE_VALID   0xA5A5A5A5UL

/** Numero di byte occupati da un campione:
    7 parole da 32 bit = 28 byte. **/
#define FLASH_SAMPLE_SIZE    28U



/** Indirizzo della prossima parola da scrivere. **/
static uint32_t flash_write_address = FLASH_START_ADDRESS;

/** Indica se la registrazione è abilitata:
    0 = registrazione disabilitata
    1 = registrazione abilitata. **/
uint8_t flash_recording_enabled = 0;



/** Aspettiamo che il controller Flash sia libero.

    Registro SR:
    BSY = 1: operazione in corso
    BSY = 0: controller disponibile. **/
static void FLASH_WaitUntilReady(void)
{
    while (FLASH->SR & FLASH_SR_BSY)
    {
    }
}


/** Sblocchiamo il controller Flash.

    Se LOCK = 1, il controller è bloccato.
    Per sbloccarlo scriviamo le due chiavi nel registro KEYR. **/
static void FLASH_Unlock(void)
{
    if (FLASH->CR & FLASH_CR_LOCK)
    {
        FLASH->KEYR = 0x45670123UL;
        FLASH->KEYR = 0xCDEF89ABUL;
    }
}


/** Configuriamo la programmazione Flash a 32 bit.

    Nel registro CR, il campo PSIZE determina
    la dimensione della programmazione.

    PSIZE = 10: programmazione a 32 bit. **/
static void FLASH_SetProgramSize(void)
{
    /** Azzeriamo i due bit PSIZE. **/
    FLASH->CR &= ~(3U << FLASH_CR_PSIZE_Pos);

    /** Impostiamo PSIZE = 10. **/
    FLASH->CR |= (2U << FLASH_CR_PSIZE_Pos);
}


/** Cancelliamo i flag di completamento e di errore
    presenti nel registro SR.

    I flag vengono cancellati scrivendo 1
    nelle rispettive posizioni. **/
static void FLASH_ClearFlags(void)
{
    FLASH->SR = FLASH_SR_EOP |
                FLASH_SR_WRPERR |
                FLASH_SR_PGAERR |
                FLASH_SR_PGPERR |
                FLASH_SR_PGSERR;
}



/** Scriviamo una parola da 32 bit nel settore 7.

    La funzione:
    - verifica che la registrazione sia abilitata;
    - verifica che ci sia spazio;
    - attende che il controller sia libero;
    - controlla che la posizione sia cancellata;
    - configura e avvia la programmazione;
    - verifica il risultato;
    - aggiorna l'indirizzo di scrittura.

    Restituisce:
    1 = scrittura riuscita
    0 = scrittura non riuscita. **/
static uint8_t FLASH_WriteWord(uint32_t data)
{
    /** Verifichiamo che la registrazione sia abilitata. **/
    if (flash_recording_enabled == 0U)
    {
        return 0;
    }

    /** Verifichiamo di non aver raggiunto
        la fine del settore 7. **/
    if (flash_write_address >= FLASH_END_ADDRESS)
    {
        return 0;
    }

    /** Aspettiamo che il controller Flash sia libero. **/
    FLASH_WaitUntilReady();

    /** Una posizione cancellata contiene tutti bit a 1.
        Non scriviamo su una posizione già utilizzata. **/
    if (*(volatile uint32_t *)flash_write_address != 0xFFFFFFFFUL)
    {
        return 0;
    }

    /** Sblocchiamo il controller Flash. **/
    FLASH_Unlock();

    /** Controlliamo che lo sblocco sia riuscito. **/
    if (FLASH->CR & FLASH_CR_LOCK)
    {
        return 0;
    }

    /** Configuriamo la programmazione a 32 bit. **/
    FLASH_SetProgramSize();

    /** Cancelliamo eventuali flag precedenti. **/
    FLASH_ClearFlags();

    /** Abilitiamo la programmazione impostando PG = 1. **/
    FLASH->CR |= FLASH_CR_PG;

    /** Scriviamo la parola all'indirizzo selezionato. **/
    *(volatile uint32_t *)flash_write_address = data;

    /** Attendiamo il completamento della programmazione. **/
    FLASH_WaitUntilReady();

    /** Disabilitiamo la programmazione riportando PG a 0. **/
    FLASH->CR &= ~FLASH_CR_PG;

    /** Verifichiamo la presenza di errori. **/
    if (FLASH->SR & (FLASH_SR_WRPERR |
                     FLASH_SR_PGAERR |
                     FLASH_SR_PGPERR |
                     FLASH_SR_PGSERR))
    {
        FLASH_ClearFlags();
        return 0;
    }

//    /** Controlliamo che l'operazione sia terminata. **/
//    if ((FLASH->SR & FLASH_SR_EOP) == 0U)
//    {
//        return 0;
//    }

    /** Cancelliamo il flag di completamento EOP. **/
    FLASH->SR = FLASH_SR_EOP;

    /** Rileggiamo la parola per verificare
        che il valore memorizzato sia corretto. **/
    if (*(volatile uint32_t *)flash_write_address != data)
    {
        return 0;
    }

    /** Avanziamo di 4 byte per la prossima parola. **/
    flash_write_address += 4U;

    return 1;
}



/** Verifichiamo che il settore 7 sia completamente vuoto.

    Leggiamo tutte le parole da 32 bit del settore.

    Una parola cancellata contiene 0xFFFFFFFF.

    Restituisce:
    1 = settore completamente vuoto
    0 = settore contenente almeno una parola utilizzata. **/
static uint8_t FLASH_IsEmpty(void)
{
    uint32_t address;

    for (address = FLASH_START_ADDRESS;
         address < FLASH_END_ADDRESS;
         address += 4U)
    {
        if (*(volatile uint32_t *)address != 0xFFFFFFFFUL)
        {
            return 0;
        }
    }

    return 1;
}



/** Convertiamo la rappresentazione binaria di un float
    in una parola da 32 bit.

    memcpy copia i 4 byte del float senza modificarli.

    Questo permette di memorizzare nella Flash
    il valore originale della variabile float. **/
static uint32_t FLASH_FloatToWord(float value)
{
    uint32_t word;

    memcpy(&word, &value, sizeof(word));

    return word;
}



/** Inizializziamo la registrazione nella Flash.

    All'avvio del programma:
    - disabilitiamo inizialmente la registrazione;
    - controlliamo il contenuto del settore 7;
    - se è vuoto, abilitiamo la registrazione;
    - se contiene dati, li conserviamo e non registriamo.

    Non viene effettuata alcuna cancellazione. **/
void FLASH_LogInit(void)
{
    /** Inizialmente disabilitiamo la registrazione. **/
    flash_recording_enabled = 0;

    /** Controlliamo se il settore 7 è vuoto. **/
    if (FLASH_IsEmpty())
    {
        /** Ripartiamo dall'inizio del settore. **/
        flash_write_address = FLASH_START_ADDRESS;

        /** Abilitiamo la registrazione. **/
        flash_recording_enabled = 1;
    }
}


/** Registriamo un campione ACC completo nella Flash.

    Ogni campione contiene sette parole da 32 bit:

    1. Tempo di campionamento in millisecondi
    2. Distanza misurata
    3. Errore rispetto alla distanza desiderata
    4. Uscita del controllore PID
    5. Valore PWM
    6. Stato della macchina a stati
    7. Marcatore di completamento

    Il marcatore viene scritto per ultimo, in modo
    da riconoscere i campioni completamente registrati.

    Restituisce:
    1 = campione scritto correttamente
    0 = registrazione non riuscita. **/
uint8_t FLASH_LogSample(uint32_t time_ms,
                        float distance,
                        float error,
                        float uk,
                        uint16_t pwm,
                        uint32_t state)
{
    /** Verifichiamo che la registrazione sia abilitata. **/
    if (flash_recording_enabled == 0U)
    {
        return 0;
    }

    /** Verifichiamo che rimangano almeno 28 byte,
        necessari per registrare un campione completo. **/
    if ((FLASH_END_ADDRESS - flash_write_address) < FLASH_SAMPLE_SIZE)
    {
        return 0;
    }

    /** Prima parola: tempo di campionamento. **/
    if (!FLASH_WriteWord(time_ms))
    {
        return 0;
    }

    /** Seconda parola: distanza misurata. **/
    if (!FLASH_WriteWord(FLASH_FloatToWord(distance)))
    {
        return 0;
    }

    /** Terza parola: errore. **/
    if (!FLASH_WriteWord(FLASH_FloatToWord(error)))
    {
        return 0;
    }

    /** Quarta parola: uscita del PID. **/
    if (!FLASH_WriteWord(FLASH_FloatToWord(uk)))
    {
        return 0;
    }

    /** Quinta parola: valore PWM. **/
    if (!FLASH_WriteWord((uint32_t)pwm))
    {
        return 0;
    }

    /** Sesta parola: stato della FSM. **/
    if (!FLASH_WriteWord(state))
    {
        return 0;
    }

    /** Settima parola: marcatore di campione completo. **/
    if (!FLASH_WriteWord(FLASH_SAMPLE_VALID))
    {
        return 0;
    }

    return 1;
}


/** Conta i campioni completi registrati nel settore 7. **/
uint32_t FLASH_CountSamples(void)
{
    /** Inizializziamo il contatore dei campioni a zero. **/
    uint32_t count = 0U;

    /** Partiamo dall'indirizzo iniziale del settore 7. **/
    uint32_t address = FLASH_START_ADDRESS;

    /** Continuiamo finché rimane spazio per un campione completo. **/
    while (address <= FLASH_END_ADDRESS - FLASH_SAMPLE_SIZE)
    {
        /** Leggiamo il marcatore nell'ultima parola del campione. **/
        uint32_t marker = *(volatile const uint32_t *)(address + 24U);

        /** Se il marcatore non è valido, interrompiamo il conteggio. **/
        if (marker != FLASH_SAMPLE_VALID)
        {
            break;
        }

        /** Incrementiamo il numero dei campioni completi. **/
        count++;

        /** Passiamo all'indirizzo del campione successivo. **/
        address += FLASH_SAMPLE_SIZE;
    }

    /** Restituiamo il numero dei campioni completi trovati. **/
    return count;
}


/** Legge un campione completo dal settore 7 della Flash. **/
uint8_t FLASH_ReadSample(uint32_t index, FLASH_Sample_t *sample)
{
    /** Verifichiamo che il puntatore alla struttura sia valido. **/
    if (sample == NULL)
    {
        return 0U;
    }

    /** Verifichiamo che l'indice non superi il numero massimo
        di campioni che possono entrare nel settore 7. **/
    if (index >= (FLASH_END_ADDRESS - FLASH_START_ADDRESS) / FLASH_SAMPLE_SIZE)
    {
        return 0U;
    }

    /** Calcoliamo l'indirizzo iniziale del campione richiesto. **/
    uint32_t address = FLASH_START_ADDRESS + index * FLASH_SAMPLE_SIZE;

    /** Leggiamo il marcatore dell'ultima parola del campione. **/
    uint32_t marker = *(volatile const uint32_t *)(address + 24U);

    /** Se il marcatore non è valido, il campione non è completo. **/
    if (marker != FLASH_SAMPLE_VALID)
    {
        return 0U;
    }

    /** Leggiamo il tempo dalla prima parola del campione. **/
    sample->time_ms = *(volatile const uint32_t *)(address);

    /** Leggiamo i bit della distanza dalla seconda parola. **/
    uint32_t word = *(volatile const uint32_t *)(address + 4U);

    /** Ricostruiamo il valore float della distanza. **/
    memcpy(&sample->distance, &word, sizeof(float));

    /** Leggiamo i bit dell'errore dalla terza parola. **/
    word = *(volatile const uint32_t *)(address + 8U);

    /** Ricostruiamo il valore float dell'errore. **/
    memcpy(&sample->error, &word, sizeof(float));

    /** Leggiamo i bit dell'uscita PID dalla quarta parola. **/
    word = *(volatile const uint32_t *)(address + 12U);

    /** Ricostruiamo il valore float dell'uscita PID. **/
    memcpy(&sample->uk, &word, sizeof(float));

    /** Leggiamo il valore PWM dalla quinta parola. **/
    sample->pwm = *(volatile const uint32_t *)(address + 16U);

    /** Leggiamo lo stato della FSM dalla sesta parola. **/
    sample->state = *(volatile const uint32_t *)(address + 20U);

    /** Comunichiamo che la lettura è stata completata. **/
    return 1U;
}


/** Cancella il settore 7 della memoria Flash.
    Restituisce 1 se la cancellazione riesce, 0 in caso di errore. **/
uint8_t FLASH_EraseSector7(void)
{
    /** Disabilitiamo la registrazione durante la cancellazione. **/
    flash_recording_enabled = 0U;

    /** Attendiamo che il controller Flash termini
        eventuali operazioni precedenti. **/
    FLASH_WaitUntilReady();

    /** Sblocchiamo il controller Flash. **/
    FLASH_Unlock();

    /** Verifichiamo che il controller sia stato sbloccato. **/
    if (FLASH->CR & FLASH_CR_LOCK)
    {
        return 0U;
    }

    /** Cancelliamo eventuali segnalazioni di operazioni
        precedenti e relativi errori. **/
    FLASH_ClearFlags();

    /** Azzeriamo i bit di selezione del settore e
        quelli relativi alla programmazione/cancellazione. **/
    FLASH->CR &= ~(FLASH_CR_PG | FLASH_CR_SER |
                   FLASH_CR_MER | FLASH_CR_SNB);

    /** Selezioniamo il settore 7 tramite il campo SNB. **/
    FLASH->CR |= (7U << FLASH_CR_SNB_Pos);

    /** Impostiamo la dimensione dell'operazione a 32 bit. **/
    FLASH_SetProgramSize();

    /** Abilitiamo la cancellazione del settore selezionato. **/
    FLASH->CR |= FLASH_CR_SER;

    /** Avviamo l'operazione di cancellazione. **/
    FLASH->CR |= FLASH_CR_STRT;

    /** Attendiamo il completamento della cancellazione. **/
    FLASH_WaitUntilReady();

    /** Verifichiamo la presenza di errori del controller Flash. **/
    uint32_t errors = FLASH->SR &
        (FLASH_SR_WRPERR | FLASH_SR_PGAERR |
         FLASH_SR_PGPERR | FLASH_SR_PGSERR);

    /** Disabilitiamo la modalità di cancellazione. **/
    FLASH->CR &= ~FLASH_CR_SER;

    /** Blocchiamo nuovamente il controller Flash. **/
    FLASH->CR |= FLASH_CR_LOCK;

    /** Se sono stati rilevati errori, segnaliamo il fallimento. **/
    if (errors != 0U)
    {
        return 0U;
    }

    /** Verifichiamo che tutte le parole del settore siano cancellate. **/
    if (FLASH_IsEmpty() == 0U)
    {
        return 0U;
    }

    /** Riportiamo l'indirizzo di scrittura all'inizio del settore. **/
    flash_write_address = FLASH_START_ADDRESS;

    /** Comunichiamo che la cancellazione è riuscita. **/
    return 1U;
}


