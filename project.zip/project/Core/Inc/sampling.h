/*
 * sampling.h
 *
 *  Created on: Oct 22, 2026
 *      Author: ludovicaperroni
 */

#ifndef INC_SAMPLING_H_
#define INC_SAMPLING_H_

#include <stdint.h>

/** Configurazione di TIM6 per la generazione del tempo di campionamento dell'ACC **/
void TIM6_basic_setup(void);

/** Flag che segnala al main il completamento del periodo di campionamento **/
extern volatile uint8_t time_elapsed;

extern volatile uint32_t sample_count;

#endif /* INC_SAMPLING_H_ */
