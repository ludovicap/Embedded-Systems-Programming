/*
 * hc_sr04.h
 *
 *  Created on: Oct 12, 2026
 *      Author: ludovicaperroni
 */

#ifndef INC_HC_SR04_H_
#define INC_HC_SR04_H_

#include "main.h"

/*
 * Funzione di inizializzazione del sensore HC_SR04
 */
void hc_sr04_init();

/** Funzione che genera l'impulso Trigger, attende la misura di Echo e calcola la distanza **/
float meas_dist();


#endif /* INC_HC_SR04_H_ */
