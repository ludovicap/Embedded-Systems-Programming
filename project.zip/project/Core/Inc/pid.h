/*
 * pid.h
 *
 *  Created on: Oct 22, 2026
 *      Author: ludovicaperroni
 */

#ifndef INC_PID_H_
#define INC_PID_H_

/** Struttura dati del controllore PID **/
typedef struct
{
	/** Guadagno proporzionale **/
	float kp;

	/** Parametri della componente integrale **/
	float ti;
	float u_i_km1;

	/** Parametri della componente derivativa **/
	float td;
	float N;
	float u_d_km1;

	/** Errore del campionamento precedente **/
	float e_km1;

	/** Periodo di campionamento **/
	float tc;

	/** Parametri della saturazione e dell'anti-windup **/
	float u_min;
	float u_max;
	float tw;

} Pid_s;

/** Creazione e inizializzazione del controllore PID **/
Pid_s *pid_create(float tc, float kp, float ti, float td, float N, float u_min, float u_max, float tw);

/** Calcolo del comando del controllore PID **/
float pid_calculate(Pid_s *pid, float measure, float reference);

#endif /* INC_PID_H_ */
