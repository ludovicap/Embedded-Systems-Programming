/*
 * usart.h
 *
 *  Created on: Oct 26, 2026
 *      Author: ludovicaperroni
 */

#ifndef INC_USART_H_
#define INC_USART_H_

#include <stdint.h>

/** Inizializzazione di USART2 **/
void USART2_init(void);

/** Trasmissione di un carattere tramite USART2 **/
void USART2_sendChar(char c);

/** Trasmissione di una stringa tramite USART2 **/
void USART2_sendString(const char *str);

/** Ricezione di un carattere tramite USART2 **/
char USART2_receiveChar(void);

/** Legge e trasmette un campione dalla Flash tramite USART2. **/
void USART2_sendSample(uint32_t index);

/** Trasmette tutti i campioni completi presenti nella Flash. **/
void USART2_sendAllSamples(void);

/** Trasmette un numero intero senza segno tramite USART2. **/
void USART2_sendNumber(uint32_t number);

#endif /* INC_USART_H_ */
