/*
 * motor_utilities.h
 *
 *  Created on: Oct 15, 2026
 *      Author: ludovicaperroni
 */

#ifndef INC_MOTOR_UTILITIES_H_
#define INC_MOTOR_UTILITIES_H_

#include <stdint.h>

/** Inizializzazione dei pin dello shift register **/
void ShiftRegister_init(void);

/** Impostazione della direzione dei motori **/
void Motor_setDirection(uint8_t direction);

/** Comandi di movimento **/
void Motor_forward(void);
void Motor_backward(void);
void Motor_stop(void);

/** Abilitazione delle uscite del 74HC595N **/
void ShiftRegister_enableOutputs(void);

/** Configurazione del PWM del motore M1 **/
void TIM3_PWM_setup(void);

/** Configurazione del PWM del motore M2 **/
void TIM2_PWM_setup(void);

/** Configurazione del PWM del motore M3 **/
void TIM2_CH3_PWM_setup(void);

/** Configurazione del PWM del motore M4 **/
void TIM3_CH1_PWM_setup(void);

/** Impostazione del PWM dei quattro motori **/
void Motor_setPWM(uint16_t pwm);

#endif /* INC_MOTOR_UTILITIES_H_ */
