
/*
 * flash.h
 *
 *  Created on: Oct 28, 2026
 *      Author: ludovicaperroni
 */

#ifndef INC_FLASH_H_
#define INC_FLASH_H_

#include "main.h"
#include <stdint.h>

/** Inizializziamo la registrazione nella Flash.

    La registrazione viene abilitata soltanto
    se il settore 7 è completamente vuoto. **/
void FLASH_LogInit(void);

/** Registriamo un campione ACC nel settore 7.

    Parametri:
    time_ms  = tempo di campionamento in millisecondi
    distance = distanza misurata
    error    = errore rispetto alla distanza desiderata
    uk       = uscita del controllore PID
    pwm      = valore PWM applicato
    state    = stato della FSM

    Restituisce:
    1 = campione registrato correttamente
    0 = registrazione non riuscita. **/
uint8_t FLASH_LogSample(uint32_t time_ms,
                        float distance,
                        float error,
                        float uk,
                        uint16_t pwm,
                        uint32_t state);

/** Rendiamo accessibile agli altri file la variabile **/
extern uint8_t flash_recording_enabled;

/** Restituisce il numero di campioni completi nel settore 7. **/
uint32_t FLASH_CountSamples(void);


/** Struttura contenente i dati di un campione ACC. **/
typedef struct
{
    uint32_t time_ms;   /** Tempo del campione in millisecondi. **/
    float distance;     /** Distanza misurata in centimetri. **/
    float error;        /** Errore rispetto alla distanza di riferimento. **/
    float uk;           /** Uscita del controllore PID. **/
    uint32_t pwm;       /** Valore PWM applicato ai motori. **/
    uint32_t state;     /** Stato della FSM. **/

} FLASH_Sample_t;

/** Legge un campione completo dalla Flash.
    Restituisce 1 se la lettura riesce, altrimenti 0. **/
uint8_t FLASH_ReadSample(uint32_t index, FLASH_Sample_t *sample);

/** Cancella il settore 7 della Flash.
    Restituisce 1 in caso di successo, 0 in caso di errore. **/
uint8_t FLASH_EraseSector7(void);


#endif /* INC_FLASH_H_ */
